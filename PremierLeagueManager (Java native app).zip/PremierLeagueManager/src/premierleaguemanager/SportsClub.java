/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleaguemanager;

public abstract class SportsClub {
    public String clubName;
    public String clubLocation;
    public int totalWins;   

 public String getClubName(){
return this.clubName;
}
 public String getClubLocation(){
 return this.clubLocation;
}
 public int getTotalWins(){
     return this.totalWins;
 }
}