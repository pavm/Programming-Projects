/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleaguemanager;

/**
 *
 * @author w1486122
 */
public class FootballClub extends SportsClub{
    public int totalWins;
    public int totalDraws;
    public int totalLoss;
    public int totalGoals;
    public int totalGoalsConceded;
    public int clubPoints;
    public int gamesPlayed;  
    
@Override
public String getClubName(){
return this.clubName;
}
@Override
 public String getClubLocation(){
 return this.clubLocation;
}
 @Override
 public int getTotalWins(){
     return this.totalWins;
 }
}
