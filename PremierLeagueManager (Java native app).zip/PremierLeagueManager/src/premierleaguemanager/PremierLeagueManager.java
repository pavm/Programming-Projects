/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleaguemanager;

import java.io.Reader;
import java.util.Scanner;


public class PremierLeagueManager implements LeagueManager {

    public static void main(String[] args) {
            Scanner reader = new Scanner(System.in);
            System.out.println("Enter the number of the option: ");           
            System.out.println("1. Create new Club to add to Premier League");
            System.out.println("2. Relegate club from Premier");
            System.out.println("3. Display statistics for club");
            System.out.println("4. Display Premier League standings");
            System.out.println("5. Add new score");
            System.out.println("6. Display calendar");               
                int optionNumber = Integer.parseInt(reader.next());
        Reader option = null;
        
         switch (optionNumber) {
            case 1:  optionNumber = 1;
            createFootballClub();
                     break;
            case 2:  optionNumber = 2;
            relegateFootballClub();
                     break;
            case 3:  optionNumber = 3;
            displayStats();
                     break;
            case 4:  optionNumber = 4;
            displayTable();
                     break;
            case 5:  optionNumber = 5;
            addMatchDetails();
                     break;
            case 6:  optionNumber = 6;
            displayCalendar();
                     break;
                
            default: System.out.println("Please enter a valid option from the menu");
                     break;
        }
    }
        public static void createFootballClub(){
            System.out.println("Create team");
        }        
        public static void relegateFootballClub(){
            System.out.println("Relegate team");
        }    
        public static void displayStats(){
            System.out.println("Show stats");
        }
        public static void displayTable(){
            System.out.println("Show table");
        }
        public static void addMatchDetails(){
            System.out.println("Add score");
        }
        public static void displayCalendar(){
            System.out.println("Display calendar");
        }
    }
    

