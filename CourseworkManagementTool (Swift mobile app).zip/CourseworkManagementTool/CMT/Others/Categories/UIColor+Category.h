//
//  UIColor+Category.h
//  AutoFacil
//
//  Created by IBINFINITE on 24/15/15.
//  Copyright (c) 2014 Bhavesh Kumbhani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Category)

+ (UIColor *) colorWithHexString: (NSString *) hexString;

@end
