//
//  CustomDropDown.h
//  CustomDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomDropDown;
@protocol CustomDropDownDelegate
- (void) CustomDropDownDelegateMethod: (CustomDropDown *) sender index:(int)index;
@end

@interface CustomDropDown : UIView <UITableViewDelegate, UITableViewDataSource>
{
    NSString *animationDirection;
    UIImageView *imgView;
    int height;
}
@property(nonatomic, strong) UIButton *btnSender;
@property (nonatomic, strong) id <CustomDropDownDelegate> delegate;
@property (nonatomic, strong) NSString *animationDirection;


-(void)hideDropDown:(UIButton *)b;
- (id)showDropDown:(UIButton *)b datalist:(NSArray *)arr direction:(NSString *)direction ht:(NSString*)ht;
@end
