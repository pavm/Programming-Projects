//
//  Course.swift
//  CMT
//
//  Created by Harveer Jandu on 30/03/17.
//  Copyright © 2017 IB. All rights reserved.
//


import Foundation
import CoreData

@objc(Course)
class Course: NSManagedObject {
    
    @NSManaged var name: String
    @NSManaged var duedate: Date
    @NSManaged var level: Double
    @NSManaged var mark: Double
    @NSManaged var modulename: String
    @NSManaged var notes: String
    @NSManaged var reminder1: Date
    @NSManaged var reminder2: Date
    @NSManaged var createdate: Date
    @NSManaged var avgvalue: Float
    @NSManaged var image: String
    @NSManaged var weight: Float
    @NSManaged var reminderid1: String
    @NSManaged var reminderid2: String
    @NSManaged var eventid: String
    @NSManaged var tasks: Set<Task>
}


