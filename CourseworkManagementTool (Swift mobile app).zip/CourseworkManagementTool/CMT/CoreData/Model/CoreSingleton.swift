//
//  CoreSingleton.swift
//  CMT
//
//  Created by Harveer Jandu on 31/03/17.
//  Copyright © 2017 IB. All rights reserved.
//

import UIKit
import CoreData

class CoreSingleton: NSObject {

    static let shared : CoreSingleton = {
        let instance = CoreSingleton()
        return instance
    }()
    
    lazy var cdstore: CoreDataStore = {
        let cdstore = CoreDataStore()
        return cdstore
    }()
    
    lazy var cdh: CoreDataHelper = {
        let cdh = CoreDataHelper()
        return cdh
    }()

    // MARK: - Init New Object
    func newCourse() -> Course! {
         let newCourse: Course = NSEntityDescription.insertNewObject(forEntityName: entity_Course, into: self.cdh.backgroundContext!) as! Course
        return newCourse
    }
    func newTask() -> Task! {
        let newTask: Task = NSEntityDescription.insertNewObject(forEntityName: entity_Task, into: self.cdh.backgroundContext!) as! Task
        return newTask
    }
    // MARK: - Save every thing
    func save() -> Void {
        self.cdh.saveContext(self.cdh.backgroundContext!)
    }
    // MARK: -
    
    func deleteCourse(course: Course!) -> Void {
        deleteAllSubTaskForCourse(course: course)
        removeImage(strName: course.image)
        ABNScheduler.deleteNotification(strID: course.reminderid1)
        ABNScheduler.deleteNotification(strID: course.reminderid2)
        EventModel.shared.deleteEvent(eventId: course.eventid)
        self.cdh.backgroundContext!.delete(course)
        self.save()
    }
    func deleteTask(task: Task!) -> Void {
        ABNScheduler.deleteNotification(strID: task.reminderid1)
        ABNScheduler.deleteNotification(strID: task.reminderid2)
        EventModel.shared.deleteEvent(eventId: task.eventid)
        self.cdh.backgroundContext!.delete(task)
        self.save()
    }
    
    func deleteAllSubTaskForCourse(course:Course) -> Void {
        for obj in course.tasks {
            deleteTask(task: obj)
        }
    }
    
    func removeImage(strName: String!) -> Void {
        
        if strName != nil {
            let strPath = GlobalModel.shared().getRootDir().appendingFormat("/%@", strName)
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: strPath) {
                do {
                    try fileManager.removeItem(atPath: strPath)
                    print("Image deleted -",strName)
                } catch  {
                    print("Image not deleted")
                }
                
            }
            
        }
    }
    
    
    func getCourseList() -> Array<Any>! {
        var result: Array<Any>?
        let fReq = NSFetchRequest<NSFetchRequestResult>(entityName: entity_Course)
        do {
            result = try self.cdh.backgroundContext?.fetch(fReq)
        } catch let nserror1 as NSError{
            result = []
            print("errer:",nserror1)
        }
        return result
    }
    
    func calculateProgress(objCourse: Course!) -> Float! {
        
        
        let totalPercentage : Float = Float(100 * objCourse.tasks.count)
        
        
        if totalPercentage > 0 {
            var sumOfTaskProgress: Float = 0.0
            for obj in objCourse.tasks {
                sumOfTaskProgress = sumOfTaskProgress + Float(obj.progress)
            }
            let avgPer = sumOfTaskProgress * 100 / totalPercentage
            return avgPer
        }
        return 0.0
        
    }
    
    
    // MARK: -
}
