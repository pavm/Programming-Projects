//
//  Task.swift
//  CMT
//
//  Created by Harveer Jandu on 30/03/17.
//  Copyright © 2017 IB. All rights reserved.
//


import Foundation
import CoreData

@objc(Task)
class Task: NSManagedObject {
    
    @NSManaged var name: String
    @NSManaged var startdate: Date
    @NSManaged var duedate: Date
    @NSManaged var notes: String
    @NSManaged var reminder1: Date
    @NSManaged var reminder2: Date
    @NSManaged var reminderid1: String
    @NSManaged var reminderid2: String
    @NSManaged var eventid: String
    @NSManaged var status: Int32
    @NSManaged var progress: Float
    @NSManaged var course: Course
}
