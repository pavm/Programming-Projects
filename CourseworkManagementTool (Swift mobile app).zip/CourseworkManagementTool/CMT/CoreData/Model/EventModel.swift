//
//  EventModel.swift
//  CMT
//
//  Created by Harveer Jandu on 04/04/17.
//  Copyright © 2017 IB. All rights reserved.
//

import UIKit
import EventKit
import EventKitUI

class EventModel: NSObject {

    var eventStore : EKEventStore! = nil
    static let shared : EventModel = {
        let instance = EventModel()
        instance.eventStore = EKEventStore.init()
        return instance
    }()
    
    func newEventWithCource(course:Course!, completion: ((_ strId : String?) -> Void)?) {
        eventStore.requestAccess(to: EKEntityType.event) { (granted:Bool?, error:Error?) in
            if (granted)! && (error == nil) {
                let event:EKEvent = EKEvent(eventStore: self.eventStore)
                event.title = course.name.appending(" - ").appending(course.modulename)
                event.startDate = course.duedate
                event.endDate = course.duedate
                event.notes = course.notes
                event.calendar = self.eventStore.defaultCalendarForNewEvents
                do {
                    try self.eventStore.save(event, span: EKSpan.thisEvent, commit: true)
                    print("New Event",event.eventIdentifier)
                    completion! (event.eventIdentifier)
                }catch{
                    completion! (nil)
                    print("Error creating and saving new event : \(error)")
                }
            }else{ // Redisect Setting for access
                let del = UIApplication.shared.delegate as! AppDelegate
                UIAlertController.showAlert(in: (del.window?.rootViewController)!, withTitle: NSLocalizedString("title-message", comment: ""), message: NSLocalizedString("calender-access-msg", comment: ""), cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Cancel","Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
                    if (index == 3){
                        UIApplication.shared.openURL(NSURL(string:UIApplicationOpenSettingsURLString)! as URL)
                    }
                })
            }
        }
    }
    
    func newEventWithTask(task:Task!, completion: ((_ strId : String?) -> Void)?) {
        eventStore.requestAccess(to: EKEntityType.event) { (granted:Bool?, error:Error?) in
            if (granted)! && (error == nil) {
                let event:EKEvent = EKEvent(eventStore: self.eventStore)
                event.title = task.name
                event.startDate = task.duedate
                event.endDate = task.duedate
                event.notes = task.notes
                event.calendar = self.eventStore.defaultCalendarForNewEvents
                do {
                    try self.eventStore.save(event, span: EKSpan.thisEvent, commit: true)
                    print("New Event",event.eventIdentifier)
                    completion! (String(event.eventIdentifier))
                }catch{
                    completion! (nil)
                    print("Error creating and saving new event : \(error)")
                }
            }else{ // Redisect Setting for access
                let del = UIApplication.shared.delegate as! AppDelegate
                UIAlertController.showAlert(in: (del.window?.rootViewController)!, withTitle: NSLocalizedString("title-message", comment: ""), message: NSLocalizedString("calender-access-msg", comment: ""), cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Cancel","Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
                    if (index == 3){
                        UIApplication.shared.openURL(NSURL(string:UIApplicationOpenSettingsURLString)! as URL)
                    }
                })
            }
        }
    }

    
    
    
    func deleteEvent(eventId: String!) -> Void {
        
        if eventId != nil {
            let event = eventStore.event(withIdentifier: eventId)
            if event != nil {            do {
                try self.eventStore.remove(event!, span: EKSpan.thisEvent)
                print("Remove Event",event?.eventIdentifier ?? "")
            }catch{
                print("Error in Remove : \(error)")
                }
            }
        }
        
    }
    func updateEventWithCourse(course:Course) -> Void {
        
        if !course.eventid.isEmpty  {
           
            if eventStore.responds(to: #selector(eventStore.event(withIdentifier:))) {
                if (eventStore.event(withIdentifier: course.eventid) != nil) {
                    let event = eventStore.event(withIdentifier: course.eventid)! as EKEvent
                    do {
                        event.title = course.name.appending(" - ").appending(course.modulename)
                        event.startDate = course.duedate
                        event.endDate = course.duedate
                        event.notes = course.notes
                        try self.eventStore.save(event, span: EKSpan.thisEvent, commit: true)
                        print("Update Event",event.eventIdentifier )
                    }catch{
                        print("Error in Update : \(error)")
                    }
                }else{ // If delete from calender again create new one
                    self.newEventWithCource(course: course, completion: { (strId:String?) in
                        if strId != nil{
                            course.eventid = strId!
                            CoreSingleton.shared.save()
                        }
                    })
                }
            }
            
        }
    }
    
    func updateEventWithTask(task:Task) -> Void {
        
        if !task.eventid.isEmpty  {
            
            if eventStore.responds(to: #selector(eventStore.event(withIdentifier:))) {
                if (eventStore.event(withIdentifier: task.eventid) != nil) {
                    let event = eventStore.event(withIdentifier: task.eventid)! as EKEvent
                    do {
                        event.title = task.name
                        event.startDate = task.duedate
                        event.endDate = task.duedate
                        event.notes = task.notes
                        try self.eventStore.save(event, span: EKSpan.thisEvent, commit: true)
                        print("Update Event",event.eventIdentifier )
                    }catch{
                        print("Error in Update : \(error)")
                    }
                }else{ // If delete from calender again create new one
                    self.newEventWithTask(task: task, completion: { (strId:String?) in
                        if strId != nil{
                            task.eventid = strId!
                            CoreSingleton.shared.save()
                        }
                    })
                }
            }
        }
    }
}
