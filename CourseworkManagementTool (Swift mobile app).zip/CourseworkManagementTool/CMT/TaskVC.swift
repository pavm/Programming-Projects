//
//  TaskVC.swift
//  CMT
//
//  Created by Harveer Jandu on 07/04/17.
//  Copyright © 2017 IB. All rights reserved.
//

protocol TaskVCDeleget {
    func courseAddUpdateNotify(course:Course!) -> Void
    func reloadData() -> Void
}

import UIKit
import YLProgressBar

class TaskVC: UIViewController, TaskUpdateDeleget, CourseUpdateDeleget, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var lblWeight: UILabel!
    @IBOutlet weak var lblLevel: UILabel!
    @IBOutlet weak var lblDayTime: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblPercnetage: UILabel!
    @IBOutlet weak var lblMark: UILabel!
    @IBOutlet weak var lblNotes: UITextView!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var progressView: YLProgressBar!
    var taskDelegate: TaskVCDeleget! = nil
    var taskList : Array<Any>!
    
    var objCource: Course!
    
    // MARK: - View Lyf Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblDayTime.layer.cornerRadius = lblDayTime.bounds.size.width/2
        lblDayTime.clipsToBounds = true
        lblDayTime.layer.borderColor = UIColor.lightGray.cgColor
        lblDayTime.layer.borderWidth = 2.0
        lblDayTime.clipsToBounds = true
        
        reloadPrgress()
        tblView.register(UINib(nibName: "TaskCell", bundle: Bundle.main), forCellReuseIdentifier: "TaskCellId")
    }
    
    func reloadPrgress() -> Void {
        if self.objCource != nil{
            self.navigationItem.title = objCource.name
            let time = (objCource.duedate as NSDate).timeCalculate()
            lblDayTime.text = String(time!)?.appending(" Left")
            lblName.text = String("Module: ")?.appending(objCource.modulename)
            lblWeight.text = String("Weight: ")?.appending(String(objCource.weight)).appending(" %")
            lblLevel.text = String("Level: ")?.appending(String(Int(objCource.level)))
            lblNotes.text = objCource.notes
            
            lblMark.text = String(Int(objCource.mark)).appending("/").appending("100")
            let prog = CoreSingleton.shared.calculateProgress(objCourse: objCource)
            let pro = NSString.init(format: "%0.2f", prog!)
            lblPercnetage.text = pro.appending("%").appending(" Compelete")
            progressView.setProgress(CGFloat(prog!/100), animated: true)
                        
            self.view.viewWithTag(100)?.isHidden = false
            self.view.viewWithTag(101)?.isHidden = false
            getTaskList()
        }else{
            DispatchQueue.main.async {
                self.view.viewWithTag(100)?.isHidden = true
                self.view.viewWithTag(101)?.isHidden = true
                self.navigationItem.title = "Task"
            }
            
        }

    }
    
    @IBAction func btnEditClick(_ sender: UIBarButtonItem) {
       
        
        if objCource != nil {
            let objVC = CourseEntryVC(nibName: "CourseEntryVC", bundle: nil) as CourseEntryVC!
            objVC?.isEditMode = true
            objVC?.delegate = self
            objVC?.objCource = objCource
            let nav = UINavigationController.init(rootViewController: objVC!)
            nav.modalPresentationStyle = .formSheet
            self.present(nav, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func EditTaskClick(_ sender: UIBarButtonItem) {
       
        
        if sender.title == "Edit" {
            self.tblView.setEditing(true, animated: true)
            sender.title = "Done"
        }else{            
            self.tblView.setEditing(false, animated: true)
            sender.title = "Edit"
        }
    }
    func courseAddUpdateNotify(course: Course!) {
       
        print("courseAddUpdateNotify - TASK")
        DispatchQueue.main.async {
             self.objCource =  course
            self.reloadPrgress()
            
            if self.taskDelegate != nil {
                self.taskDelegate.courseAddUpdateNotify(course: course)
            }else{
                let nc = NotificationCenter.default
                nc.post(name: NSNotification.Name(rawValue: "reloadData"), object: nil)
            }
        }        
    }
    
    @IBAction func addNewTaskClick(_ sender: UIBarButtonItem) {
        
        let objVC = TaskEntryVC(nibName: "TaskEntryVC", bundle: nil) as TaskEntryVC!
        objVC?.isEditMode = false
        objVC?.delegate = self
        objVC?.objCource = objCource
        let nav = UINavigationController.init(rootViewController: objVC!)
        nav.modalPresentationStyle = .formSheet
        self.present(nav, animated: true, completion: nil)
    }
    
    func taskAddUpdateNotify(task: Task!) {
        print("taskAddUpdateNotify - TASK")
        
        DispatchQueue.main.async {
            self.getTaskList()
            self.reloadPrgress()
            let nc = NotificationCenter.default
            nc.post(name: NSNotification.Name(rawValue: "reloadData"), object: nil)
        }
        
    }
    func getTaskList() -> Void {
        
        if taskList != nil {
            taskList.removeAll()
        }else{
            taskList = Array.init()
        }
        for obj in objCource.tasks {
            print("Name:",obj.name)
            taskList.append(obj)
        }
        self.tblView.reloadData()
    }
    
    // MARK: - tableView Delegates
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return taskList == nil ? 0 : taskList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: TaskCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "TaskCellId") as! TaskCell!
        
        let objTask = taskList[indexPath.row] as! Task
        cell?.lblName.text = objTask.name
        cell?.progressView.progress = Float(CGFloat(objTask.progress/100))
        cell?.lblNotes.text = objTask.notes
        let pro = NSString.init(format: "%0.2f", objTask.progress)
        cell?.lblPercentage.text = pro.appending("%").appending(" completed")
        let time = (objTask.duedate as NSDate).timeCalculate()
        cell?.lblDayTime.text = String(time!)?.appending(" Left")
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        tableView.deselectRow(at: indexPath, animated: true)
        let objTask = taskList[indexPath.row] as! Task
        let objVC = TaskEntryVC(nibName: "TaskEntryVC", bundle: nil) as TaskEntryVC!
        objVC?.isEditMode = true
        objVC?.delegate = self
        objVC?.objCource = objCource
        objVC?.objTask = objTask
        let nav = UINavigationController.init(rootViewController: objVC!)
        nav.modalPresentationStyle = .formSheet
        self.present(nav, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 86
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let objTask = taskList[indexPath.row] as! Task
            CoreSingleton.shared.deleteTask(task: objTask)
            taskList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath as IndexPath], with: .fade)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

