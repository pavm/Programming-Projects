//
//  GlobalModel.h
//  CMT
//
//  Created by Harveer Jandu on 31/03/17.
//  Copyright © 2017 IB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GlobalModel : NSObject
+ (GlobalModel*)shared;
- (NSString*)isNilValidate:(UITextField*)txt;
- (NSString*)getUniqeID;
- (NSString*)getRootDir;
- (NSString*)getImagePathFromName:(NSString*)imgName;
@end
