//
//  GlobalModel.m
//  CMT
//
//  Created by Harveer Jandu on 31/03/17.
//  Copyright © 2017 IB. All rights reserved.
//

#import "GlobalModel.h"

@implementation GlobalModel
+ (GlobalModel*)shared{
    static GlobalModel *objGM;
    if (objGM==nil) {
        objGM=[[[self class] alloc]init];
    }
    return objGM;
}
- (NSString*)isNilValidate:(UITextField*)txt{
    
   if ([[txt.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
        NSString *strAlertMsg;
        strAlertMsg = [NSString stringWithFormat:@"%@%@.",NSLocalizedString(@"nil-validate-textfeild", @""),txt.placeholder.lowercaseString];
        return strAlertMsg;
   }
    return nil;
    
}
- (NSString*)getUniqeID{
    return [[[[NSUUID UUID] UUIDString] substringToIndex:5] lowercaseString];
}
- (NSString*)getRootDir{
    return [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
}
- (NSString*)getImagePathFromName:(NSString*)imgName{
    
    return [[self getRootDir] stringByAppendingPathComponent:imgName];
}

@end
