//
//  TaskCell.swift
//  CMT
//
//  Created by Harveer Jandu on 09/04/17.
//  Copyright © 2017 Harveer Jandu. All rights reserved.
//

import UIKit

class TaskCell: UITableViewCell {

    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblDayTime: UILabel!
    @IBOutlet var lblNotes: UITextView!
    @IBOutlet var lblPercentage: UILabel!
    @IBOutlet var progressView: UIProgressView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
