//
//  CourseEntryVC.swift
//  CMT
//
//  Created by Harveer Jandu on 08/04/17.
//  Copyright © 2017 Harveer Jandu. All rights reserved.
//



protocol CourseUpdateDeleget {
    func courseAddUpdateNotify(course:Course!) -> Void;
}

import UIKit
import SkyFloatingLabelTextField
import DBAttachmentPickerController
import RMDateSelectionViewController
import RMActionController

class CourseEntryVC: UIViewController, UITextFieldDelegate, CustomDropDownDelegate {
    


    var isEditMode: Bool! = nil
    var prevText : UITextField!
    var dueDate: Date!
    var reminderDate1: Date!
    var reminderDate2: Date!
    var dropDown: CustomDropDown!
    var delegate: CourseUpdateDeleget! = nil
    var objCource: Course!
    var isImageChange:Bool!
    
    @IBOutlet var txtCourseName: SkyFloatingLabelTextField!
    @IBOutlet var txtModuleName: SkyFloatingLabelTextField!
    @IBOutlet var txtDueDate: SkyFloatingLabelTextField!
    @IBOutlet var txtWeight: SkyFloatingLabelTextField!
    @IBOutlet var txtLevel: SkyFloatingLabelTextField!
    @IBOutlet var txtNotes: SkyFloatingLabelTextField!
    @IBOutlet var txtReminder1: SkyFloatingLabelTextField!
    @IBOutlet var txtReminder2: SkyFloatingLabelTextField!
    
    @IBOutlet var markSlider: UISlider!
    @IBOutlet var lblMark: UILabel!
    @IBOutlet var imgPicker: UIImageView!
    
    
    
    // MARK: - View Lyf Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let closeButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(closeVC(_:)))
        self.navigationItem.leftBarButtonItem = closeButton
        
        let saveButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveCourse(_:)))
        self.navigationItem.rightBarButtonItem = saveButton
        txtWeight.keyboardType = UIKeyboardType.decimalPad
        isImageChange = false
        
        
        
        if isEditMode! {
            self.navigationItem.title = "Edit Course"
            txtCourseName.text = objCource.name
            txtModuleName.text = objCource.modulename
            txtDueDate.text = (objCource.duedate as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
            dueDate = objCource.duedate
            txtLevel.text = String(objCource.level)
            txtWeight.text = String(objCource.weight)
            txtNotes.text = (objCource?.notes.isEmpty)! ? "" : (objCource?.notes)!
            lblMark.text = String("0/")?.appending(String(Int(objCource.mark)))
            markSlider.value = Float(objCource.mark)
            
            print("Model:",objCource)
            
            if !objCource.image.isEmpty{
                let path = GlobalModel.shared().getImagePath(fromName: objCource.image)
               imgPicker.image = UIImage.init(contentsOfFile: path!)
            }
            if !objCource.reminderid1.isEmpty {
                reminderDate1 = objCource.reminder1
                txtReminder1.text = (objCource.reminder1 as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
                ABNScheduler.deleteNotification(strID: objCource.reminderid1)
            }
            if !objCource.reminderid2.isEmpty {
                reminderDate2 = objCource.reminder2
                txtReminder2.text = (objCource.reminder2 as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
                ABNScheduler.deleteNotification(strID: objCource.reminderid2)
            }
        }else{
            self.navigationItem.title = "New Course"
            txtReminder1.isEnabled = false
            txtReminder2.isEnabled = false
        }
        
    }
    func closeVC(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func saveCourse(_ sender: Any) {
        
        if let msg = GlobalModel.shared().isNilValidate(txtCourseName){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        
        if let msg = GlobalModel.shared().isNilValidate(txtModuleName){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }

        if let msg = GlobalModel.shared().isNilValidate(txtDueDate){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        
        if let msg = GlobalModel.shared().isNilValidate(txtWeight){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        if let msg = GlobalModel.shared().isNilValidate(txtLevel){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        
        var imgName:String! = ""
        
        if !isEditMode  {
            objCource = CoreSingleton.shared.newCourse()
        }
        
        objCource?.name = txtCourseName.text!
        objCource?.modulename = txtModuleName.text!
        objCource?.createdate = Date.init()
        objCource?.duedate = dueDate
        objCource?.level = Double(txtLevel.text!)!
        objCource?.mark = Double(Int(markSlider.value))
        objCource?.weight = Float(txtWeight.text!)!
        objCource?.notes = txtNotes.text!
        
        // Image Stuff **********************************
        var isWriteFile: Bool! = false
        if isImageChange == true && isEditMode == true{ // Edit
            if !objCource.image.isEmpty{
                imgName = objCource.image
                CoreSingleton.shared.removeImage(strName: imgName)
            }else{
                imgName = (String(GlobalModel.shared().getUniqeID())?.appending(".jpg"))! as String
            }
            isWriteFile = true
        }else if isImageChange == true && isEditMode == false{ // Create  New
            isWriteFile = true
            imgName = (String(GlobalModel.shared().getUniqeID())?.appending(".jpg"))! as String
        }else if isEditMode == true &&  !objCource.image.isEmpty {
            imgName = objCource.image
        }
        objCource?.image = imgName
        
        if isWriteFile!{
            let strPath = GlobalModel.shared().getRootDir().appendingFormat("/%@", imgName)
            print("Path:", strPath)
            let fileManager = FileManager.default
            fileManager.createFile(atPath: strPath as String, contents: UIImageJPEGRepresentation(imgPicker.image!,0.1), attributes: nil)
        }
        //************************************************
        
        let strBody = objCource?.name.appending(" - ").appending((objCource?.modulename)!)
        if reminderDate1 != nil {
            objCource?.reminder1 = reminderDate1
            let note = ABNotification(alertBody: strBody!)
            objCource?.reminderid1 = note.schedule(fireDate: reminderDate1)!
        }
        if reminderDate2 != nil {
            objCource?.reminder2 = reminderDate2
            let note = ABNotification(alertBody: strBody!)
            objCource?.reminderid2 = note.schedule(fireDate: reminderDate2)!
        }
        
        if isEditMode == true{
            EventModel.shared.updateEventWithCourse(course: objCource)
            CoreSingleton.shared.cdh.saveContext()
            DispatchQueue.main.async {
                if self.delegate != nil {
                    self.delegate.courseAddUpdateNotify(course: self.objCource)
                }
            }
            self.dismiss(animated: true, completion: nil)
        }else{
            
            EventModel.shared.newEventWithCource(course: objCource) { (strId:String?) in
                if strId != nil{
                    self.objCource?.eventid = strId!
                    CoreSingleton.shared.cdh.saveContext()
                    
                    DispatchQueue.main.async {
                        if self.delegate != nil {
                            self.delegate.courseAddUpdateNotify(course: self.objCource)
                        }
                    }
                    
                    self.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    // MARK: - UITextField Delegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
    
        let txt : SkyFloatingLabelTextField = textField as! SkyFloatingLabelTextField
        
        if prevText != nil{
            prevText.resignFirstResponder()
        }
        if txt.title == "Due Date:" || txt.title == "Reminder 1:" || txt.title == "Reminder 2:"{
            pickDate(txt: txt)
            return false;
        }
        prevText =  textField
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var limitLength = 30
        
        let txt : SkyFloatingLabelTextField = textField as! SkyFloatingLabelTextField
        let title = txt.title! as String
        guard let text = textField.text else { return true }
        if title == "Weigth:" {
            limitLength = 3
            let inverseSet = NSCharacterSet(charactersIn:"0123456789.").inverted
            let components = string.components(separatedBy: inverseSet)
            let filtered = components.joined(separator: "")
             if string == filtered
             {
                
             }else{
                return false
            }
           
            let resultString = text.appending(string)
            
            if Float(resultString)! > 100 {
                return false
            }
        } else if title == "Notes:" {
            limitLength = 100
        }
        let t1 = text.replacingOccurrences(of: ".", with: "").characters.count
        let t2 = string.replacingOccurrences(of: ".", with: "").characters.count - range.length
        let newLength = t1 + t2
        return newLength <= limitLength
    }
    
    func pickDate(txt:SkyFloatingLabelTextField) -> Void {
        
        let selectAction = RMAction.init(title: "Done", style: .done) { (controller:RMActionController<UIDatePicker>) in
          
            let date = controller.contentView.date
            
            if txt.title == "Due Date:" {
                self.dueDate = date
                self.txtReminder1.isEnabled = true
                self.txtReminder2.isEnabled = true
            }else if txt.title == "Reminder 1:" {
                self.reminderDate1 = date
            }else if txt.title == "Reminder 2:" {
                self.reminderDate2 = date
            }
            txt.text = (date as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
            
        }
        let cancelAction = RMAction.init(title: "Cancel", style: .cancel) { (controller:RMActionController<UIDatePicker>) in
            
        }
        let nowAction = RMAction<UIDatePicker>(title: "Now", style: .additional) { controller -> Void in
            controller.contentView.date = Date.init();
            let date = controller.contentView.date
            
            if txt.title == "Due Date:" {
                self.dueDate = date
                self.txtReminder1.isEnabled = true
                self.txtReminder2.isEnabled = true
            }else if txt.title == "Reminder 1:" {
                self.reminderDate1 = date
            }else if txt.title == "Reminder 2:" {
                self.reminderDate2 = date
            }
            txt.text = (date as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
        }
        nowAction!.dismissesActionController = false;
        
        let controller = RMDateSelectionViewController.init(style: .black, title: String("Select ")?.appending((txt.placeholder?.capitalized)!), message: "", select: selectAction, andCancel: cancelAction)
       
        controller?.contentView.minimumDate = Date.init()
        
        controller?.addAction(nowAction!)
        if txt.title == "Due Date:" {
            if dueDate != nil {
                controller?.contentView.date = dueDate
            }
        }else if txt.title == "Reminder 1:" {
            if reminderDate1 != nil {
                controller?.contentView.date = reminderDate1
            }
            if dueDate != nil {
                controller?.contentView.maximumDate = dueDate
            }
        }else if txt.title == "Reminder 2:" {
            if reminderDate2 != nil {
                controller?.contentView.date = reminderDate2
            }
            if dueDate != nil {
                controller?.contentView.maximumDate = dueDate
            }
        }
        self.present(controller!, animated: true, completion: nil)
    }
    
    @IBAction func btnLevelPick(_ sender: UIButton) {
        if prevText != nil{
            prevText.resignFirstResponder()
        }
        if(dropDown == nil){
            dropDown = CustomDropDown.init()
            dropDown.show(sender, datalist: ["Level 4","Level 5","Level 6","Level 7"], direction: "down", ht: "160")
            dropDown.delegate = self;
        }else{
            dropDown.hide(sender)
            dropDown = nil;
        }
    }
    
    func customDropDownDelegateMethod(_ sender: CustomDropDown!, index: Int32) {
        dropDown.hide(sender.btnSender)
        dropDown = nil;
        let list  =  ["4","5","6","7"]
        txtLevel.text = list[Int(index)]
    }
    @IBAction func markSliderChange(_ sender: UISlider) {
        lblMark.text = String(Int(sender.value)).appending("/").appending("100")
    }
    
    @IBAction func imageTapedGwsture(_ sender: UITapGestureRecognizer) {
   
        let attachmentPickerController = DBAttachmentPickerController.imagePickerControllerFinishPicking({ (_ images: [UIImage]) in
            self.imgPicker.image = images[0]
            self.isImageChange = true
        }) { 
            
        }
        attachmentPickerController.mediaType = .image
        attachmentPickerController.allowsMultipleSelection = false
        attachmentPickerController.allowsSelectionFromOtherApps = false
        attachmentPickerController.present(on: self)
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
