//
//  CourseworkVC.swift
//  CMT
//
//  Created by Harveer Jandu on 07/04/17.
//  Copyright © 2017 IB. All rights reserved.
//

import UIKit
import CoreData
import YLProgressBar

class CourseworkVC: UITableViewController, CourseUpdateDeleget,TaskVCDeleget {
    
    var objTaskVC: TaskVC? = nil
    var courseList : Array<Any>!
    
    
    // MARK: - View Lyf Cycle
    // title
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Coursework"
        
        // edit navigation button
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        
        // add navigation button
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        self.navigationItem.rightBarButtonItem = addButton
        
        // changes made in course, updates the second view controllar
        if let split = self.splitViewController {
            let controllers = split.viewControllers
            self.objTaskVC = (controllers[controllers.count-1] as! UINavigationController).topViewController as? TaskVC
            self.objTaskVC?.taskDelegate = self
        }
        // how both controllars listen to each other, obervation deisgn patten
        let nc = NotificationCenter.default
        nc.removeObserver(self, name: NSNotification.Name(rawValue: "reloadData"), object: nil)
        nc.addObserver(self,
                       selector: #selector(reloadData),
                       name: NSNotification.Name(rawValue: "reloadData"),
                       object: nil)
        
    }
    
    func getCourceList() -> Void {
        courseList = CoreSingleton.shared.getCourseList()
        self.tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.isCollapsed
        super.viewWillAppear(animated)
        getCourceList()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // TaskVCDeleget Methods
    func courseAddUpdateNotify(course: Course!) {
        print("courseAddUpdateNotify:", course.name)
        getCourceList()       
    }
    func reloadData() {
        getCourceList()
    }
    // creating course object
    func insertNewObject(_ sender: Any) {
        let objVC = CourseEntryVC(nibName: "CourseEntryVC", bundle: nil) as CourseEntryVC!
        objVC?.isEditMode = false
        objVC?.delegate = self
        let nav = UINavigationController.init(rootViewController: objVC!)
        nav.modalPresentationStyle = .formSheet
    self.present(nav, animated: true, completion: nil)
    // diplsays pop up
    }
    
    
    // MARK: - Segues
    
    // displays course details on the taskvc
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let objModel = courseList[indexPath.row] as! Course
                let controller = (segue.destination as! UINavigationController).topViewController as! TaskVC
                controller.objCource = objModel
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
    
    // MARK: - Table View
    // tableview delegate and data view source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    // how maney course e.g. rows
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return courseList.count
    }
    // displaying protoype cell, access views
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let objModel = courseList[indexPath.row] as! Course
        
        if !objModel.image.isEmpty{
            let path = GlobalModel.shared().getImagePath(fromName: objModel.image)
            
            if let imgView = cell.contentView.viewWithTag(100) as? UIImageView   {
                imgView.image = UIImage.init(contentsOfFile: path!)
                imgView.layer.cornerRadius = 3
                imgView.layer.borderWidth = 1
                imgView.layer.borderColor = UIColor.lightGray.cgColor
                imgView.clipsToBounds = true
            }
        }
        if let lblName = cell.contentView.viewWithTag(101) as? UILabel   {
            lblName.text = objModel.name.capitalized
        }
        if let lblModule = cell.contentView.viewWithTag(102) as? UILabel   {
            lblModule.text =  objModel.modulename.capitalized
        }
        if let lblDueDate = cell.contentView.viewWithTag(103) as? UILabel   {
            lblDueDate.text = (objModel.duedate as NSDate).mediumDateString
        }
        if let lblWeight = cell.contentView.viewWithTag(104) as? UILabel   {
            lblWeight.text = String("Weight:")?.appending(String(objModel.weight)).appending("%")
        }
        if let lblLevel = cell.contentView.viewWithTag(105) as? UILabel   {
            lblLevel.text = String("Level: ")?.appending(String(objModel.level))
        }
        if let lblDayTime = cell.contentView.viewWithTag(106) as? UILabel   {
            lblDayTime.text = (objModel.duedate as NSDate).timeCalculate()
        }
        /*if let lblStatus = cell.contentView.viewWithTag(107) as? UILabel   {
            lblStatus.layer.cornerRadius = lblStatus.bounds.size.width/2
            lblStatus.clipsToBounds = true
        }*/
        if let progress1 = cell.contentView.viewWithTag(108) as? YLProgressBar   {
            let strProg = CoreSingleton.shared.calculateProgress(objCourse: objModel)
            if  progress1.stripesOrientation != .left {
                progress1.stripesOrientation = .left
                progress1.indicatorTextDisplayMode = .progress
                progress1.indicatorTextLabel.font = UIFont.systemFont(ofSize: 14)
                progress1.progressStretch = false
            }            
            progress1.setProgress(CGFloat(strProg!/100.0), animated: true)
        }        
        return cell
    }
    // allow to edit
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        // Return false if you do not want the specified item to be editable.
        return true
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            // removes from coredata
            let objModel = courseList[indexPath.row] as! Course
            CoreSingleton.shared.deleteCourse(course: objModel)
            courseList.remove(at: indexPath.row)
            
            // remove from data
            tableView.deleteRows(at: [indexPath as IndexPath], with: .fade)
           // rrefresh and cal progress
            DispatchQueue.main.async {
                if let split = self.splitViewController {
                    let controllers = split.viewControllers
                    self.objTaskVC = (controllers[controllers.count-1] as! UINavigationController).topViewController as? TaskVC
                    self.objTaskVC?.objCource = nil
                    self.objTaskVC?.reloadPrgress()
                }
            }
        }
    }    
}

