//
//  TaskEntryVC.swift
//  CMT
//
//  Created by Harveer Jandu on 09/04/17.
//  Copyright © 2017 Harveer Jandu. All rights reserved.
//



protocol TaskUpdateDeleget {
    func taskAddUpdateNotify(task:Task!) -> Void;
}

import UIKit
import SkyFloatingLabelTextField
import RMDateSelectionViewController
import RMActionController

let statusList  =  ["Not done","Minor defect","Major defect","Compelete"]

class TaskEntryVC: UIViewController, UITextFieldDelegate, CustomDropDownDelegate {
    


    var isEditMode: Bool! = nil
    var prevText : UITextField!
    var dueDate: Date!
    var startDate: Date!
    var reminderDate1: Date!
    var reminderDate2: Date!
    var dropDown: CustomDropDown!
    var delegate: TaskUpdateDeleget! = nil
    var objCource: Course!
    var objTask: Task!
    var statusIndex: Int32!
    
    @IBOutlet var txtTaskName: SkyFloatingLabelTextField!
    @IBOutlet var txtStartDate: SkyFloatingLabelTextField!
    @IBOutlet var txtDueDate: SkyFloatingLabelTextField!
    @IBOutlet var txtStatus: SkyFloatingLabelTextField!
    @IBOutlet var txtNotes: SkyFloatingLabelTextField!
    @IBOutlet var txtReminder1: SkyFloatingLabelTextField!
    @IBOutlet var txtReminder2: SkyFloatingLabelTextField!
    
    @IBOutlet var progressSlider: UISlider!
    @IBOutlet var lblProgress: UILabel!
    
    // MARK: - View Lyf Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let closeButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(closeVC(_:)))
        self.navigationItem.leftBarButtonItem = closeButton
        
        let saveButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTask(_:)))
        self.navigationItem.rightBarButtonItem = saveButton
        
        
        
        if isEditMode! {
            self.navigationItem.title = "Edit Task"
            
            txtTaskName.text = objTask.name
            txtStartDate.text = (objTask.startdate as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
            txtDueDate.text = (objTask.duedate as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
            startDate = objTask.startdate
            dueDate = objTask.duedate
            txtStatus.text = statusList[Int((objTask?.status)!)]
            statusIndex = objTask?.status
            lblProgress.text = String(Int((objTask?.progress)!)).appending("%")
            progressSlider.value = Float((objTask?.progress)!)
            txtNotes.text! = (objTask?.notes.isEmpty)! ? "" : (objTask?.notes)!
          
            if !objTask.reminderid1.isEmpty {
                reminderDate1 = objTask.reminder1
                txtReminder1.text = (objTask.reminder1 as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
                ABNScheduler.deleteNotification(strID: objTask.reminderid1)
            }
            if !objTask.reminderid2.isEmpty {
                reminderDate2 = objTask.reminder2
                txtReminder2.text = (objTask.reminder2 as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
                ABNScheduler.deleteNotification(strID: objTask.reminderid2)
            }
            
        }else{
            self.navigationItem.title = "New Task"
            self.txtReminder1.isEnabled = false
            self.txtReminder2.isEnabled = false
            self.txtDueDate.isEnabled = false
        }
    }
    func closeVC(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func saveTask(_ sender: Any) {
        
        if let msg = GlobalModel.shared().isNilValidate(txtTaskName){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        
        if let msg = GlobalModel.shared().isNilValidate(txtStartDate){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }

        if let msg = GlobalModel.shared().isNilValidate(txtDueDate){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        
        if let msg = GlobalModel.shared().isNilValidate(txtStatus){
            UIAlertController.showAlert(in: self, withTitle: NSLocalizedString("title-message", comment: ""), message: msg, cancelButtonTitle: nil, destructiveButtonTitle: nil, otherButtonTitles: ["Ok"], tap: { (alv: UIAlertController, action : UIAlertAction, index : Int) in
            })
            return;
        }
        if !isEditMode {
            objTask = CoreSingleton.shared.newTask()
        }
        objTask?.name = txtTaskName.text!
        objTask?.startdate = startDate
        objTask?.duedate = dueDate
        objTask?.status = statusIndex
        objTask?.progress = progressSlider.value
        objTask?.notes = txtNotes.text!
        objTask?.course = objCource!
        
        let strBody = objTask?.name
        if reminderDate1 != nil {
            objTask?.reminder1 = reminderDate1
            let note = ABNotification(alertBody: strBody!)
            objTask?.reminderid1 = note.schedule(fireDate: reminderDate1)!
        }
        if reminderDate2 != nil {
             objTask?.reminder2 = reminderDate2
            let note = ABNotification(alertBody: strBody!)
            objTask?.reminderid2 = note.schedule(fireDate: reminderDate2)!
        }
                
        if isEditMode == true{
            EventModel.shared.updateEventWithTask(task: objTask)
            CoreSingleton.shared.cdh.saveContext()
            DispatchQueue.main.async {
                if self.delegate != nil {
                    self.delegate.taskAddUpdateNotify(task: self.objTask)
                }
            }
            self.dismiss(animated: true, completion: nil)
        }else{
            EventModel.shared.newEventWithTask(task: objTask) { (strId:String?) in
                if strId != nil{
                    self.objTask?.eventid = strId!
                    CoreSingleton.shared.cdh.saveContext()
                   
                    DispatchQueue.main.async {
                        if self.delegate != nil {
                            self.delegate.taskAddUpdateNotify(task: self.objTask)
                        }
                    }
                    self.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    
    // MARK: - UITextField Delegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
    
        let txt : SkyFloatingLabelTextField = textField as! SkyFloatingLabelTextField
        
        if prevText != nil{
            prevText.resignFirstResponder()
        }
        if txt.title == "Due Date:" || txt.title == "Reminder 1:" || txt.title == "Reminder 2:" || txt.title == "Start Date:"  {
            pickDate(txt: txt)
            return false;
        }
        prevText =  textField
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var limitLength = 30
        
        let txt : SkyFloatingLabelTextField = textField as! SkyFloatingLabelTextField
        let title = txt.title! as String
        
        guard let text = textField.text else { return true }
        
        if title == "Notes:" {
            limitLength = 100
        }
        let t1 = text.replacingOccurrences(of: ".", with: "").characters.count
        let t2 = string.replacingOccurrences(of: ".", with: "").characters.count - range.length
        let newLength = t1 + t2
        return newLength <= limitLength
        
    }
    
    func pickDate(txt:SkyFloatingLabelTextField) -> Void {
        
        
        let selectAction = RMAction.init(title: "Done", style: .done) { (controller:RMActionController<UIDatePicker>) in
            
            let date = controller.contentView.date
            if txt.title == "Due Date:" {
                self.dueDate = date
                self.txtReminder1.isEnabled = true
                self.txtReminder2.isEnabled = true
            }else if txt.title == "Reminder 1:" {
                self.reminderDate1 = date
            }else if txt.title == "Reminder 2:" {
                self.reminderDate2 = date
            }else if txt.title == "Start Date:" {
                self.startDate = date
                self.txtDueDate.isEnabled = true
            }
            txt.text = (date as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
            
        }
        let cancelAction = RMAction.init(title: "Cancel", style: .cancel) { (controller:RMActionController<UIDatePicker>) in
            
        }
        let nowAction = RMAction<UIDatePicker>(title: "Now", style: .additional) { controller -> Void in
            controller.contentView.date = Date.init();
            let date = controller.contentView.date
            
            if txt.title == "Due Date:" {
                self.dueDate = date
                self.txtReminder1.isEnabled = true
                self.txtReminder2.isEnabled = true
            }else if txt.title == "Reminder 1:" {
                self.reminderDate1 = date
            }else if txt.title == "Reminder 2:" {
                self.reminderDate2 = date
            }else if txt.title == "Start Date:" {
                self.startDate = date
                self.txtDueDate.text = ""
                self.dueDate = nil
                self.txtDueDate.isEnabled = true
            }          
            txt.text = (date as NSDate).string(withFormat: "dd/MM/YYYY hh:mm aa")
        }
        nowAction!.dismissesActionController = false;
        
        let controller = RMDateSelectionViewController.init(style: .black, title: String("Select ")?.appending((txt.placeholder?.capitalized)!), message: "", select: selectAction, andCancel: cancelAction)! as RMDateSelectionViewController
        
        controller.contentView.minimumDate = Date.init()
        
        if txt.title == "Due Date:" {
            controller.contentView.minimumDate = self.startDate
            if self.dueDate != nil {
                controller.contentView.date = self.dueDate
            }
        }else if txt.title == "Start Date:" {
            if self.startDate != nil {
                controller.contentView.date = self.startDate
            }
        }else if txt.title == "Reminder 1:" {
            controller.contentView.maximumDate = self.dueDate
            if self.reminderDate1 != nil {
                controller.contentView.date = self.reminderDate1
            }
            if self.dueDate != nil {
                controller.contentView.maximumDate = self.dueDate
            }
        }else if txt.title == "Reminder 2:" {
            if self.reminderDate2 != nil {
                controller.contentView.date = self.reminderDate2
            }
            if self.dueDate != nil {
                controller.contentView.maximumDate = self.dueDate
            }
        }
        controller.addAction(nowAction!)
        self.present(controller, animated: true, completion: nil)
    }
    
    @IBAction func btnStatusPick(_ sender: UIButton) {
        if prevText != nil{
            prevText.resignFirstResponder()
        }
        
        if(dropDown == nil){
            dropDown = CustomDropDown.init()
            dropDown.show(sender, datalist: statusList, direction: "down", ht: "160")
            dropDown.delegate = self;
        }else{
            dropDown.hide(sender)
            dropDown = nil;
        }
    }
    
    func customDropDownDelegateMethod(_ sender: CustomDropDown!, index: Int32) {
        dropDown.hide(sender.btnSender)
        dropDown = nil;
        statusIndex = index
        txtStatus.text = statusList[Int(index)]
    }
    @IBAction func progressSliderChange(_ sender: UISlider) {
        lblProgress.text = String(Int(sender.value)).appending("%")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
